package io.bespoke.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Lightweight vector glyphs drawn in black and white. No emoji/color icon dependency. */
final class SymbolView extends View {
    final String symbol;
    boolean light = false;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    SymbolView(Context context,String kind){super(context);symbol=kind;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float side=Math.min(getWidth(),getHeight());
        canvas.save();canvas.translate((getWidth()-side)/2f,(getHeight()-side)/2f);
        canvas.scale(side/24f,side/24f);
        paint.setColor(light?Color.WHITE:Color.rgb(24,24,24));
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.8f);
        paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
        switch(symbol){
            case "book": {
                Path a=new Path();a.moveTo(12,20);a.cubicTo(9,17.5f,5,17,2,18);a.lineTo(2,4);a.cubicTo(6,2.3f,9,3,12,5);a.cubicTo(15,3,18,2.3f,22,4);a.lineTo(22,18);a.cubicTo(19,17,15,17.5f,12,20);
                canvas.drawPath(a,paint);canvas.drawLine(12,5,12,20,paint);break;
            }
            case "apps": {
                for(int x=0;x<2;x++) for(int y=0;y<2;y++) canvas.drawRoundRect(new RectF(2+x*11.5f,2+y*11.5f,10+x*11.5f,10+y*11.5f),1.4f,1.4f,paint);
                break;
            }
            case "refresh": {
                canvas.drawArc(new RectF(4,4,20,20),205,215,false,paint);
                canvas.drawArc(new RectF(4,4,20,20),25,215,false,paint);
                Path p=new Path();p.moveTo(20,3);p.lineTo(20,9);p.lineTo(14,9);
                canvas.drawPath(p,paint);p.reset();p.moveTo(4,21);p.lineTo(4,15);p.lineTo(10,15);canvas.drawPath(p,paint);break;
            }
            case "gear": {
                canvas.drawCircle(12,12,7,paint);canvas.drawCircle(12,12,2.6f,paint);
                for(int i=0;i<8;i++){double a=(i*Math.PI)/4;canvas.drawLine(12+(float)Math.cos(a)*8,12+(float)Math.sin(a)*8,12+(float)Math.cos(a)*10.9f,12+(float)Math.sin(a)*10.9f,paint);}break;
            }
            case "light": {
                canvas.drawArc(new RectF(6,4.5f,18,17.8f),168,204,false,paint);
                canvas.drawLine(9.2f,16.8f,9.2f,19.3f,paint);canvas.drawLine(14.8f,16.8f,14.8f,19.3f,paint);
                canvas.drawRoundRect(new RectF(9.1f,19.2f,14.9f,21.4f),.6f,.6f,paint);
                canvas.drawLine(12,1,12,2.6f,paint);canvas.drawLine(4,5,5.4f,6.3f,paint);
                canvas.drawLine(20,5,18.6f,6.3f,paint);canvas.drawLine(2,11,3.9f,11,paint);canvas.drawLine(22,11,20.1f,11,paint);break;
            }
            case "back": {
                canvas.drawLine(15,4,7,12,paint);canvas.drawLine(7,12,15,20,paint);break;
            }
            default: {canvas.drawCircle(12,12,8,paint);}
        }
        canvas.restore();
    }
}
