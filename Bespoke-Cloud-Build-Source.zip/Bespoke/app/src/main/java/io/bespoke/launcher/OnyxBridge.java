package io.bespoke.launcher;

import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.view.View;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;

/**
 * Experimental, non-root device integration. Only acts through supported APIs or
 * writable system files; never changes firmware or runs privileged commands.
 * BOOX Poke 2 has multiple firmware builds: graceful fallback is essential.
 */
final class OnyxBridge {
    private OnyxBridge() { }

    @SuppressWarnings({"rawtypes", "unchecked"})
    static boolean setLauncherRefreshMode(Context context, View view, String mode) {
        // This controls BESPOKE'S view updates only, not Kindle/Kotatsu/system modes.
        try {
            Class<?> epd = Class.forName("com.onyx.android.sdk.device.EpdController");
            Class<?> modeClass = Class.forName("com.onyx.android.sdk.device.EpdController$UpdateMode");
            String candidate = "Manga".equals(mode) ? "REGAL" : "Fast".equals(mode) ? "GU_FAST" : "GU";
            Object value;
            try { value = Enum.valueOf((Class<Enum>)modeClass, candidate); }
            catch (IllegalArgumentException missing) {
                // Some older Onyx SDK releases do not expose REGAL or GU_FAST.
                return false;
            }
            Method method = epd.getMethod("setViewDefaultUpdateMode", View.class, modeClass);
            method.invoke(null, view, value);
            view.invalidate();
            return true;
        } catch (Throwable ignored) { return false; }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    static boolean fullRefresh(View view) {
        try {
            Class<?> epd = Class.forName("com.onyx.android.sdk.device.EpdController");
            Class<?> modeClass = Class.forName("com.onyx.android.sdk.device.EpdController$UpdateMode");
            Object gc = Enum.valueOf((Class<Enum>)modeClass, "GC");
            epd.getMethod("invalidate", View.class, modeClass).invoke(null, view, gc);
            return true;
        } catch (Throwable ignored) {
            view.invalidate();
            return false;
        }
    }

    // Very low Poke 2 white-light preset: 3/255 (~1% raw level).
    // Some firmware won't grant ordinary apps permission to change this sysfs node.
    private static final String LIGHT = "/sys/class/backlight/white/brightness";
    static boolean tryToggleFrontlight() {
        try {
            File f = new File(LIGHT);
            if (!f.isFile() || !f.canWrite() || !f.canRead()) return false;
            int previous;
            try (FileInputStream in = new FileInputStream(f)) {
                byte[] buf = new byte[32]; int read = in.read(buf);
                previous = Integer.parseInt(new String(buf, 0, read, StandardCharsets.US_ASCII).trim());
            }
            int next = previous > 0 ? 0 : 3;
            try (FileOutputStream out = new FileOutputStream(f)) {
                out.write(Integer.toString(next).getBytes(StandardCharsets.US_ASCII));
            }
            return true;
        } catch (Exception e) { return false; }
    }

    static Intent displaySettings() { return new Intent(Settings.ACTION_DISPLAY_SETTINGS); }
}
