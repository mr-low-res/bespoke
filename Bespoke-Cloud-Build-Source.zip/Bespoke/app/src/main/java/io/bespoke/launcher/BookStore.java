package io.bespoke.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Local-only bookshelf. Bespoke never tries to access another app's private database. */
final class BookStore {
    static final class Book {
        String id = "";
        String title = "";
        String appName = "";
        String appPackage = "";
        String coverUri = "";
        int progress = 0;
        String chapter = "";
        long openedAt = 0;
        JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("id", id); o.put("title", title); o.put("appName", appName);
                o.put("appPackage", appPackage); o.put("coverUri", coverUri);
                o.put("progress", progress); o.put("chapter", chapter); o.put("openedAt", openedAt);
            } catch (Exception ignored) { }
            return o;
        }
        static Book fromJson(JSONObject o) {
            Book b = new Book();
            b.id = o.optString("id", ""); b.title = o.optString("title", "");
            b.appName = o.optString("appName", ""); b.appPackage = o.optString("appPackage", "");
            b.coverUri = o.optString("coverUri", ""); b.progress = o.optInt("progress", 0);
            b.chapter = o.optString("chapter", ""); b.openedAt = o.optLong("openedAt", 0);
            return b;
        }
    }
    private final SharedPreferences prefs;
    BookStore(Context context) { prefs = context.getSharedPreferences("bespoke", Context.MODE_PRIVATE); }
    List<Book> all() {
        ArrayList<Book> books = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs.getString("books", "[]"));
            for (int i=0; i<a.length(); i++) books.add(Book.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) { }
        Collections.sort(books, (a,b) -> Long.compare(b.openedAt, a.openedAt));
        return books;
    }
    void save(Book book) {
        List<Book> books = all();
        books.removeIf(b -> b.id.equals(book.id));
        books.add(0, book);
        persist(books);
    }
    void delete(String id) {
        List<Book> books = all();
        books.removeIf(b -> b.id.equals(id));
        persist(books);
    }
    Book byId(String id) {
        for (Book b : all()) if (b.id.equals(id)) return b;
        return null;
    }
    String getText(String key, String defaultValue) { return prefs.getString(key, defaultValue); }
    void putText(String key, String value) { prefs.edit().putString(key, value).apply(); }
    int getNumber(String key, int defaultValue) { return prefs.getInt(key, defaultValue); }
    void putNumber(String key, int value) { prefs.edit().putInt(key, value).apply(); }
    boolean getFlag(String key, boolean defaultValue) { return prefs.getBoolean(key, defaultValue); }
    void putFlag(String key, boolean value) { prefs.edit().putBoolean(key, value).apply(); }
    private void persist(List<Book> books) {
        JSONArray a = new JSONArray();
        for (int i=0; i<Math.min(books.size(), 60); i++) a.put(books.get(i).toJson());
        prefs.edit().putString("books", a.toString()).apply();
    }
}
