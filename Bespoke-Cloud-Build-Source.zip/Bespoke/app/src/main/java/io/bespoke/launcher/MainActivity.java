package io.bespoke.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** BESPOKE: a lightweight reading-first home screen for Android 9 / BOOX Poke 2. */
public final class MainActivity extends Activity {
    private static final int BLACK = Color.rgb(21,21,21);
    private static final int GRAY = Color.rgb(95,95,95);
    private static final int LIGHT = Color.rgb(220,220,220);
    private static final int WHITE = Color.WHITE;
    private static final int COVER_REQUEST = 1001;
    private static final int WIDGET_BIND = 1002;
    private static final int WIDGET_CONFIG = 1003;
    private static final int HOST_ID = 24008;

    private final ArrayList<ResolveInfo> installed = new ArrayList<>();
    private LinearLayout screen, body, bottomBar;
    private BookStore store;
    private AppWidgetHost widgetHost;
    private AppWidgetManager widgetManager;
    private String page = "home";
    private String coverBookId = null;
    private int pendingWidget = -1;
    private String search = "";
    private boolean recentList = false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(WHITE);
        getWindow().setNavigationBarColor(WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        store = new BookStore(this);
        widgetHost = new AppWidgetHost(this, HOST_ID);
        widgetManager = AppWidgetManager.getInstance(this);
        loadInstalledApps();
        buildShell();
        showPage("home");
    }
    @Override public void onStart() { super.onStart(); try { widgetHost.startListening(); } catch (Exception ignored) { } }
    @Override public void onStop() { try { widgetHost.stopListening(); } catch (Exception ignored) { } super.onStop(); }
    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); showPage("home"); }
    @Override public void onBackPressed() { if (!page.equals("home")) showPage("home"); else super.onBackPressed(); }

    private int d(float dp) { return (int)(dp * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int fill, int stroke, int radius, int strokeWidth) {
        GradientDrawable a = new GradientDrawable(); a.setColor(fill); a.setCornerRadius(d(radius));
        if (strokeWidth > 0) a.setStroke(d(strokeWidth), stroke);
        return a;
    }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout col() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView text(String txt, float size, boolean bold) {
        TextView t = new TextView(this); t.setText(txt); t.setTextColor(BLACK); t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setIncludeFontPadding(false); return t;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : d(w), h < 0 ? h : d(h)); }
    private LinearLayout.LayoutParams weighted(int w, int h, float weight) { return new LinearLayout.LayoutParams(w < 0 ? w : d(w), h < 0 ? h : d(h), weight); }
    private void pad(View v,int a,int b,int c,int e){v.setPadding(d(a),d(b),d(c),d(e));}
    private void gap(LinearLayout container, int height) { View v = new View(this); container.addView(v,lp(1,height)); }
    private void rule(LinearLayout host) { View v=new View(this);v.setBackgroundColor(Color.rgb(190,190,190));host.addView(v,lp(-1,1)); }
    private View glyph(String symbol, int dpSize) { SymbolView v=new SymbolView(this,symbol); v.setLayoutParams(lp(dpSize,dpSize)); return v; }
    private void tip(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }

    private void buildShell() {
        screen = col(); screen.setBackgroundColor(WHITE);
        setContentView(screen);
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true); scroller.setVerticalScrollBarEnabled(false);
        body = col(); pad(body,15,14,15,8); scroller.addView(body);
        screen.addView(scroller,new LinearLayout.LayoutParams(-1,0,1f));
        bottomBar = col(); screen.addView(bottomBar,lp(-1,77));
    }
    private void showPage(String dest) {
        page=dest; body.removeAllViews();
        switch(dest) {
            case "recents": renderRecents(); break;
            case "library": renderLibrary(); break;
            case "apps": renderApps(); break;
            case "settings": renderSettings(); break;
            default: renderHome(); break;
        }
        renderNav();
        body.invalidate();
    }

    private void heading(String icon, String label, String trailing, Runnable action) {
        LinearLayout h=row(); h.setGravity(Gravity.CENTER_VERTICAL);
        h.addView(glyph(icon,25));
        TextView title=text(label,23,true); LinearLayout.LayoutParams t=weighted(0,42,1);
        t.leftMargin=d(8); h.addView(title,t);
        if (trailing!=null) {
            TextView b=outlined(trailing,14,false);
            pad(b,14,0,14,0);
            h.addView(b,lp(-2,36));
            b.setOnClickListener(v->action.run());
        }
        body.addView(h,lp(-1,50));
    }
    private TextView outlined(String label,int fontSize,boolean selected){
        TextView b=text(label,fontSize,true);b.setGravity(Gravity.CENTER);
        b.setBackground(bg(selected?BLACK:WHITE,BLACK,12,1)); b.setTextColor(selected?WHITE:BLACK);
        return b;
    }
    private void renderNav() {
        bottomBar.removeAllViews();
        rule(bottomBar);
        LinearLayout nav=row();pad(nav,6,6,6,2);
        addNav(nav,"book","Library",()->showPage("library"),page.equals("library"));
        addNav(nav,"apps","Apps",()->showPage("apps"),page.equals("apps"));
        addNav(nav,"refresh","Refresh",()->{
            boolean real=OnyxBridge.fullRefresh(screen);
            if (!real) tip("Requested redraw. BOOX full refresh needs a compatible E Ink driver.");
        },false);
        addNav(nav,"gear","Settings",()->showPage("settings"),page.equals("settings"));
        bottomBar.addView(nav,lp(-1,75));
    }
    private void addNav(LinearLayout nav,String icon,String label,Runnable action,boolean active){
        LinearLayout item=col();item.setGravity(Gravity.CENTER); item.setBackground(bg(active?BLACK:WHITE,BLACK,10,0));
        SymbolView sym=new SymbolView(this,icon);sym.light=active; item.addView(sym,lp(28,28));
        TextView txt=text(label,12,active);txt.setTextColor(active?WHITE:BLACK);txt.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams p=lp(-1,20); p.topMargin=d(2);item.addView(txt,p);
        LinearLayout.LayoutParams button=new LinearLayout.LayoutParams(0,-1,1);button.setMargins(d(2),0,d(2),0);nav.addView(item,button);
        item.setOnClickListener(v->action.run());
    }

    private void renderHome() {
        heading("book","Currently Reading",null,null);
        gap(body,8);
        List<BookStore.Book> books=store.all();
        BookStore.Book b=books.size()>0?books.get(0):null;
        LinearLayout hero=row(); hero.setGravity(Gravity.CENTER_VERTICAL);
        int screenWidthPx = getResources().getDisplayMetrics().widthPixels;
        float density = getResources().getDisplayMetrics().density;
        int availableDp=(int)(screenWidthPx/density)-30;
        int coverW=Math.round(availableDp*0.58f);
        int coverH=Math.round(coverW*1.34f);
        boolean homeWidget=store.getFlag("kotatsu_home",false) && store.getNumber("kotatsu_widget",-1)!=-1;
        View cover=homeWidget?homeKotatsuWidget(coverW,coverH):cover(b,coverW,coverH);
        hero.addView(cover,lp(coverW,coverH));
        if(!homeWidget) {
            cover.setOnClickListener(v->{ if(b!=null) openBook(b); else addBook(); });
            cover.setOnLongClickListener(v->{ if(b!=null) bookActions(b); else addBook();return true; });
        }
        LinearLayout details=col();pad(details,11,7,0,0);
        TextView title=text(homeWidget?"Kotatsu-Redo":b==null?"Your next read":b.title,Math.max(16,Math.min(21,availableDp/18)),true);
        title.setMaxLines(3);details.addView(title,lp(-1,-2));
        gap(details,9);
        TextView app=text(homeWidget?"Recent manga":b==null?"Choose a book":(b.appName.isEmpty()?"Reading app":b.appName),13,false);
        app.setTextColor(GRAY);details.addView(app,lp(-1,-2));
        gap(details,12);
        String progress=homeWidget?"Live widget":b==null?"Tap cover to add a book":(b.progress+"%"+(b.chapter.trim().isEmpty()?"":"  ·  "+b.chapter));
        TextView status=text(progress,13,false);status.setMaxLines(3);details.addView(status,lp(-1,-2));
        gap(details,10);
        if(b!=null && !homeWidget) details.addView(progress(b.progress),lp(-1,4));
        details.addView(new View(this),new LinearLayout.LayoutParams(1,0,1));
        TextView recent=outlined("◷  Recents   ›",15,false);details.addView(recent,lp(-1,45));
        recent.setOnClickListener(v->showPage("recents"));
        hero.addView(details,new LinearLayout.LayoutParams(0,d(coverH),1));
        body.addView(hero,lp(-1,coverH));
        gap(body,19);
        renderModeButtons();
    }
    private View homeKotatsuWidget(int w,int h) {
        FrameLayout frame=new FrameLayout(this);
        frame.setBackground(bg(Color.rgb(247,247,247),BLACK,12,1));frame.setClipToOutline(true);
        int id=store.getNumber("kotatsu_widget",-1);
        AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(id);
        if(info!=null) {
            try {
                AppWidgetHostView widget=widgetHost.createView(this,id,info);
                frame.addView(widget,new FrameLayout.LayoutParams(-1,-1));
                return frame;
            }catch(Exception ignored) { }
        }
        TextView fallback=text("Kotatsu widget unavailable\nOpen Settings to reconnect",14,true);
        fallback.setGravity(Gravity.CENTER);frame.addView(fallback,new FrameLayout.LayoutParams(-1,-1));return frame;
    }

    private View progress(int n) {
        FrameLayout track=new FrameLayout(this);track.setBackground(bg(LIGHT,LIGHT,5,0));
        View fill=new View(this);fill.setBackground(bg(BLACK,BLACK,5,0));
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,-1);
        track.addView(fill,p);
        track.post(()->{
            ViewGroup.LayoutParams fp=fill.getLayoutParams();fp.width=Math.max(1,(track.getWidth()*Math.max(0,Math.min(100,n)))/100);fill.setLayoutParams(fp);
        });
        return track;
    }
    private void renderModeButtons(){
        LinearLayout group=row();String selected=store.getText("refresh_mode","Manga");
        String[] buttons={"Normal","Manga","Fast"};
        for(String name:buttons){
            TextView b=outlined(name,15,name.equals(selected));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,d(72),1);p.setMargins(d(2),0,d(3),0);
            group.addView(b,p);
            b.setOnClickListener(v->{
                boolean supported=OnyxBridge.setLauncherRefreshMode(this,screen,name);
                store.putText("refresh_mode",name);
                showPage("home");
                if(!supported) new AlertDialog.Builder(this).setTitle(name+" mode")
                    .setMessage("Saved your preferred mode. Direct switching is unavailable on this firmware, so other apps will still use their BOOX E Ink settings. Open BOOX's E Ink Center from the top system panel to change them.")
                    .setPositiveButton("OK",null).show();
                else tip("Applied to Bespoke; other apps retain their own E Ink settings.");
            });
        }
        FrameLayout lightFrame=new FrameLayout(this);lightFrame.setBackground(bg(WHITE,BLACK,12,1));
        SymbolView bulb=new SymbolView(this,"light");FrameLayout.LayoutParams cent=new FrameLayout.LayoutParams(d(35),d(35),Gravity.CENTER);
        lightFrame.addView(bulb,cent);
        LinearLayout.LayoutParams lightLp=new LinearLayout.LayoutParams(0,d(72),.72f);lightLp.setMargins(d(3),0,d(2),0);
        group.addView(lightFrame,lightLp);
        lightFrame.setOnClickListener(v->{
            if (OnyxBridge.tryToggleFrontlight()) tip("Poke 2 white front light toggled between off and low.");
            else new AlertDialog.Builder(this).setTitle("Front light")
                .setMessage("This firmware does not permit direct front-light control. Use the BOOX brightness control in the notification panel. The 0% ↔ 1% shortcut needs device-specific testing.")
                .setNegativeButton("Cancel",null)
                .setPositiveButton("Display settings",(di,which)->safeStart(OnyxBridge.displaySettings())).show();
        });
        body.addView(group,lp(-1,72));
    }
    private ImageView cover(BookStore.Book book, int w, int h) {
        ImageView view=new ImageView(this);view.setScaleType(ImageView.ScaleType.CENTER_CROP);
        view.setBackground(bg(Color.rgb(235,235,235),BLACK,12,1));
        view.setClipToOutline(true);
        try {
            InputStream input;
            if(book!=null && !book.coverUri.isEmpty()) input=getContentResolver().openInputStream(Uri.parse(book.coverUri));
            else input=getAssets().open("demo_cover.jpg");
            try(InputStream close=input) {
                BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=2;
                Bitmap image=BitmapFactory.decodeStream(close,null,options);
                if(image!=null) view.setImageBitmap(image);
            }
        } catch (Exception ex) {
            try(InputStream fallback=getAssets().open("demo_cover.jpg")) {
                view.setImageBitmap(BitmapFactory.decodeStream(fallback));
            } catch(Exception ignored) { }
        }
        view.setContentDescription(book==null?"Choose a book":book.title);
        return view;
    }

    private void renderRecents(){
        heading("back","Recents","+ Add",this::addBook);
        gap(body,10);
        addKotatsuWidgetIfConnected();
        List<BookStore.Book> books=store.all();
        if (books.isEmpty()) emptyBooks(); else drawBookGrid(books);
    }
    private void renderLibrary(){
        heading("book","Library","+ Add",this::addBook);
        gap(body,10);
        TextView description=text("Your saved covers",14,false);description.setTextColor(GRAY);
        body.addView(description,lp(-1,35));
        List<BookStore.Book> books=store.all();
        if (books.isEmpty()) emptyBooks(); else drawBookGrid(books);
        gap(body,12);
        TextView info=text("Tip: long-press a cover to change its image, edit progress or remove it.",12,false);
        info.setTextColor(GRAY);body.addView(info,lp(-1,-2));
    }
    private void emptyBooks(){
        LinearLayout box=col();box.setGravity(Gravity.CENTER);pad(box,20,32,20,32);
        box.setBackground(bg(Color.rgb(247,247,247),BLACK,14,1));
        box.addView(glyph("book",54));gap(box,12);
        TextView t=text("Add your first book or manga",16,true);t.setGravity(Gravity.CENTER);box.addView(t,lp(-1,-2));
        gap(box,10);
        TextView d=text("Pick a cover image, choose its reading app, and track progress. Connected Kotatsu-Redo widgets can show recent manga separately.",13,false);
        d.setGravity(Gravity.CENTER);d.setTextColor(GRAY);box.addView(d,lp(-1,-2));gap(box,18);
        TextView add=outlined("Add book",15,false);box.addView(add,lp(-1,42));add.setOnClickListener(v->addBook());
        body.addView(box,lp(-1,-2));
    }
    private void drawBookGrid(List<BookStore.Book> books){
        for (int i=0;i<books.size();i+=2) {
            LinearLayout r=row();r.setGravity(Gravity.TOP);
            addBookCard(r,books.get(i));
            if(i+1<books.size()) addBookCard(r,books.get(i+1));
            else { View blank=new View(this);r.addView(blank,new LinearLayout.LayoutParams(0,d(10),1)); }
            body.addView(r,lp(-1,-2));gap(body,18);
        }
    }
    private void addBookCard(LinearLayout row, BookStore.Book b){
        LinearLayout card=col();
        LinearLayout.LayoutParams holder=new LinearLayout.LayoutParams(0,-2,1);
        holder.setMargins(d(4),0,d(4),0);row.addView(card,holder);
        // Keep card images in book-cover ratio across different Poke 2 font/DPI settings.
        int width=(int)(getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density/2)-27;
        ImageView image=cover(b,width,Math.round(width*1.38f));
        card.addView(image,lp(-1,Math.round(width*1.38f)));
        TextView title=text(b.title,16,true);title.setMaxLines(2);
        LinearLayout.LayoutParams tp=lp(-1,-2);tp.topMargin=d(7);card.addView(title,tp);
        String subtitle=(b.appName.isEmpty()?"Reading app":b.appName)+"  ·  "+b.progress+"%";
        TextView source=text(subtitle,12,false);source.setTextColor(GRAY);source.setMaxLines(2);
        LinearLayout.LayoutParams sp=lp(-1,-2);sp.topMargin=d(4);card.addView(source,sp);
        LinearLayout.LayoutParams pp=lp(-1,4);pp.topMargin=d(8);card.addView(progress(b.progress),pp);
        card.setOnClickListener(v->openBook(b));
        card.setOnLongClickListener(v->{bookActions(b);return true;});
    }

    private void loadInstalledApps() {
        installed.clear();
        Intent intent=new Intent(Intent.ACTION_MAIN);intent.addCategory(Intent.CATEGORY_LAUNCHER);
        installed.addAll(getPackageManager().queryIntentActivities(intent,0));
        Collections.sort(installed,(a,b)->String.CASE_INSENSITIVE_ORDER.compare(label(a),label(b)));
    }
    private String label(ResolveInfo info) { return info.loadLabel(getPackageManager()).toString(); }
    private String pkg(ResolveInfo info) { return info.activityInfo.packageName; }
    private boolean reading(ResolveInfo i) {
        String s=(label(i)+" "+pkg(i)).toLowerCase(Locale.ROOT);
        return s.contains("kindle") || s.contains("koreader") || s.contains("neoreader") || s.contains("readera") ||
                s.contains("readest") || s.contains("moon+") || s.contains("libby") || s.contains("pocketbook");
    }
    private boolean manga(ResolveInfo i) {
        String s=(label(i)+" "+pkg(i)).toLowerCase(Locale.ROOT);
        return s.contains("kotatsu") || s.contains("mihon") || s.contains("tachiyomi") ||
                s.contains("perfect viewer") || s.contains("comic screen") || s.contains("manga");
    }
    private void renderApps() {
        heading("apps","Apps","⌕ Search",()->showAppSearch());
        gap(body,12);
        LinearLayout sections=col();body.addView(sections,lp(-1,-2));
        renderAppSections(sections,search);
    }
    private void showAppSearch() {
        EditText query=new EditText(this);query.setSingleLine(true);query.setText(search);
        query.setHint("Search installed apps");pad(query,20,8,20,8);
        new AlertDialog.Builder(this).setTitle("Find an app").setView(query)
            .setPositiveButton("Search",(di,which)->{search=query.getText().toString().trim();showPage("apps");})
            .setNeutralButton("Clear",(di,which)->{search="";showPage("apps");})
            .setNegativeButton("Cancel",null).show();
    }
    private void renderAppSections(LinearLayout sections,String filter) {
        sections.removeAllViews();
        ArrayList<ResolveInfo> read=new ArrayList<>(),comic=new ArrayList<>(),other=new ArrayList<>();
        for(ResolveInfo app:installed) {
            if(pkg(app).equals(getPackageName())) continue;
            if(!label(app).toLowerCase(Locale.ROOT).contains(filter.toLowerCase(Locale.ROOT))) continue;
            if(manga(app)) comic.add(app); else if(reading(app)) read.add(app); else other.add(app);
        }
        if (!read.isEmpty()) appGroup(sections,"Reading",read);
        if (!comic.isEmpty()) appGroup(sections,"Manga & Comics",comic);
        if (!other.isEmpty()) appGroup(sections,"Utilities & Apps",other);
        if(read.isEmpty() && comic.isEmpty() && other.isEmpty()) sections.addView(text("No matching apps",15,false),lp(-1,80));
    }
    private void appGroup(LinearLayout sections,String name,List<ResolveInfo> apps){
        TextView h=text(name,20,true);LinearLayout.LayoutParams hp=lp(-1,40);hp.topMargin=d(6);
        sections.addView(h,hp);
        for(int i=0;i<apps.size();i+=4){
            LinearLayout r=row();r.setGravity(Gravity.TOP);
            for(int j=0;j<4;j++) {
                if(i+j<apps.size()) appIcon(r,apps.get(i+j));
                else r.addView(new View(this),new LinearLayout.LayoutParams(0,d(80),1));
            }
            sections.addView(r,lp(-1,-2));gap(sections,13);
        }
        gap(sections,7);
    }
    private void appIcon(LinearLayout r,ResolveInfo info){
        LinearLayout cell=col();cell.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);
        cp.setMargins(d(2),0,d(2),0);r.addView(cell,cp);
        FrameLayout frame=new FrameLayout(this);frame.setBackground(bg(WHITE,BLACK,12,1));
        int available=(int)(getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density)-30;
        int side=(available-24)/4;
        cell.addView(frame,lp(-1,side));
        ImageView icon=new ImageView(this);
        try {icon.setImageDrawable(info.loadIcon(getPackageManager()));} catch(Exception ignored) { }
        ColorMatrix grayscale=new ColorMatrix();grayscale.setSaturation(0);
        icon.setColorFilter(new ColorMatrixColorFilter(grayscale));
        FrameLayout.LayoutParams inside=new FrameLayout.LayoutParams(d(37),d(37),Gravity.CENTER);frame.addView(icon,inside);
        TextView name=text(label(info),12,false);name.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);name.setMaxLines(2);
        LinearLayout.LayoutParams np=lp(-1,-2);np.topMargin=d(5);cell.addView(name,np);
        cell.setOnClickListener(v->launchApp(info));
    }
    private void launchApp(ResolveInfo info){
        try {
            Intent launch=new Intent(Intent.ACTION_MAIN);launch.addCategory(Intent.CATEGORY_LAUNCHER);
            launch.setClassName(info.activityInfo.packageName,info.activityInfo.name);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch(Exception e) { tip("Couldn't open "+label(info)); }
    }
    private void openBook(BookStore.Book b) {
        b.openedAt=System.currentTimeMillis();store.save(b);
        if(!b.appPackage.isEmpty()) {
            Intent launch=getPackageManager().getLaunchIntentForPackage(b.appPackage);
            if(launch!=null) {safeStart(launch);return;}
        }
        tip("No reading app selected. Long-press to edit this book.");
    }
    private void safeStart(Intent intent){
        try {startActivity(intent);} catch(Exception e){tip("This action isn't available on your device.");}
    }
    private void addBook() { editBook(null); }
    private void editBook(BookStore.Book existing) {
        LinearLayout form=col();pad(form,24,8,24,8);
        EditText title=new EditText(this);title.setSingleLine(true);title.setHint("e.g. Frieren");
        if(existing!=null) title.setText(existing.title);
        form.addView(text("Title",13,true),lp(-1,23));form.addView(title,lp(-1,47));
        gap(form,8);
        EditText pct=new EditText(this);pct.setSingleLine(true);pct.setInputType(InputType.TYPE_CLASS_NUMBER);
        pct.setHint("0–100");pct.setText(String.valueOf(existing==null?0:existing.progress));
        form.addView(text("Progress (%)",13,true),lp(-1,23));form.addView(pct,lp(-1,47));
        gap(form,8);
        EditText chapter=new EditText(this);chapter.setSingleLine(true);chapter.setHint("e.g. Chapter 24 of 35 (optional)");
        if(existing!=null) chapter.setText(existing.chapter);
        form.addView(text("Chapter (optional)",13,true),lp(-1,23));form.addView(chapter,lp(-1,47));
        gap(form,8);
        ArrayList<ResolveInfo> readers=new ArrayList<>();
        ArrayList<String> labels=new ArrayList<>(); labels.add("No app selected");
        for (ResolveInfo app:installed) if(reading(app)||manga(app)) {readers.add(app);labels.add(label(app));}
        // Also allow any installed app, including less common reading apps.
        for (ResolveInfo app:installed) if(!readers.contains(app) && !pkg(app).equals(getPackageName())) {readers.add(app);labels.add(label(app));}
        android.widget.Spinner apps=new android.widget.Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        apps.setAdapter(adapter);
        if(existing!=null) for(int i=0;i<readers.size();i++) if(pkg(readers.get(i)).equals(existing.appPackage)) {apps.setSelection(i+1);break;}
        form.addView(text("Open using",13,true),lp(-1,23));form.addView(apps,lp(-1,52));
        String titleDialog=existing==null?"Add a book or manga":"Edit book";
        new AlertDialog.Builder(this).setTitle(titleDialog).setView(form)
            .setPositiveButton("Save",(di,which)->{
                String name=title.getText().toString().trim();
                if(name.isEmpty()) {tip("Please enter a title.");return;}
                BookStore.Book b=existing==null?new BookStore.Book():existing;
                if(b.id.isEmpty()) b.id=String.valueOf(System.nanoTime());
                b.title=name;b.chapter=chapter.getText().toString().trim();
                try {b.progress=Math.max(0,Math.min(100,Integer.parseInt(pct.getText().toString().trim())));}
                catch(Exception ignored) {b.progress=0;}
                int pos=apps.getSelectedItemPosition()-1;
                if(pos>=0 && pos<readers.size()) {b.appPackage=pkg(readers.get(pos));b.appName=label(readers.get(pos));}
                else {b.appPackage="";b.appName="";}
                b.openedAt=System.currentTimeMillis();store.save(b);
                showPage(existing==null?"library":page);
                if(existing==null) new AlertDialog.Builder(this).setTitle("Choose cover")
                    .setMessage("Would you like to select the cover image for this book? You can change it later by long-pressing the card.")
                    .setPositiveButton("Select image",(dialog,idx)->chooseCover(b))
                    .setNegativeButton("Later",null).show();
            }).setNegativeButton("Cancel",null).show();
    }
    private void bookActions(BookStore.Book b) {
        String[] options={"Open in reading app", "Change cover image", "Edit title / progress / app", "Make most recent", "Remove from Bespoke"};
        new AlertDialog.Builder(this).setTitle(b.title).setItems(options,(dialog,n)->{
            switch(n) {
                case 0:openBook(b);break;
                case 1:chooseCover(b);break;
                case 2:editBook(b);break;
                case 3:b.openedAt=System.currentTimeMillis();store.save(b);showPage("home");break;
                case 4:new AlertDialog.Builder(this).setTitle("Remove book?")
                    .setMessage("This removes the entry from Bespoke only. The book and reading app are unaffected.")
                    .setNegativeButton("Cancel",null)
                    .setPositiveButton("Remove",(di,w)->{store.delete(b.id);showPage(page);}).show();break;
            }
        }).show();
    }
    private void chooseCover(BookStore.Book b) {
        coverBookId=b.id;
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        pick.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {startActivityForResult(pick,COVER_REQUEST);}catch(Exception e){tip("No file picker available.");}
    }

    private void renderSettings(){
        heading("gear","Bespoke Settings",null,null);
        gap(body,8);
        sectionLabel("Books & manga");
        setting("Add book or manga","Choose cover, progress and reading app",this::addBook);
        setting("Open Library","Edit your saved books",()->showPage("library"));
        gap(body,16);
        sectionLabel("Kotatsu-Redo");
        setting("Connect recent-manga widget","Show the official Kotatsu-Redo widget in Recents",this::selectKotatsuWidget);
        if(store.getNumber("kotatsu_widget",-1)!=-1) {
            setting(store.getFlag("kotatsu_home",false)?"Home cover: Kotatsu widget ✓":"Home cover: manual book",
                "Toggle live Kotatsu-Redo widget as the oversized Home cover",()->{
                store.putFlag("kotatsu_home",!store.getFlag("kotatsu_home",false));showPage("settings");
            });
            setting("Remove connected widget","Disconnect without affecting Kotatsu-Redo",this::disconnectWidget);
        }
        gap(body,16);
        sectionLabel("E Ink & device");
        setting("Display and front light","Open Android/BOOX display settings",()->safeStart(OnyxBridge.displaySettings()));
        setting("Choose default launcher","Select Bespoke as the Home app",()->safeStart(new Intent(Settings.ACTION_HOME_SETTINGS)));
        setting("Test full refresh","Request a full E Ink redraw",()->{
            if(!OnyxBridge.fullRefresh(screen))tip("BOOX E Ink controller unavailable. Basic redraw attempted.");
        });
        gap(body,18);
        TextView legal=text("Bespoke 0.1  ·  Poke 2 preview\n\nYour book covers and progress are stored on this device. Kotatsu-Redo's widget is supplied by Kotatsu-Redo itself. Bespoke doesn't access any app's private database. E Ink mode buttons affect Bespoke when the official SDK supports them; other apps retain independent settings. The low-light toggle is experimental.",12,false);
        legal.setTextColor(GRAY);legal.setLineSpacing(d(3),1f);body.addView(legal,lp(-1,-2));
    }
    private void sectionLabel(String label){
        TextView h=text(label,17,true);body.addView(h,lp(-1,36));rule(body);gap(body,7);
    }
    private void setting(String title,String description,Runnable action){
        LinearLayout line=col();pad(line,8,8,8,8);
        TextView t=text(title,15,true);line.addView(t,lp(-1,27));
        TextView d=text(description,12,false);d.setTextColor(GRAY);line.addView(d,lp(-1,-2));
        body.addView(line,lp(-1,-2));line.setOnClickListener(v->action.run());
        gap(body,7);
    }
    private void selectKotatsuWidget() {
        List<AppWidgetProviderInfo> all=widgetManager.getInstalledProviders();
        ArrayList<AppWidgetProviderInfo> choices=new ArrayList<>();
        ArrayList<String> names=new ArrayList<>();
        for(AppWidgetProviderInfo p:all) {
            String provider=p.provider.getPackageName().toLowerCase(Locale.ROOT);
            if(provider.contains("kotatsu")) {choices.add(p);names.add(p.label==null?p.provider.getClassName():p.label);}
        }
        if(choices.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Kotatsu-Redo widget not found")
                .setMessage("Install or open Kotatsu-Redo and verify that its recent-manga widget is available. This feature uses Android's normal widget permission flow.")
                .setPositiveButton("OK",null).show();return;
        }
        new AlertDialog.Builder(this).setTitle("Choose Kotatsu-Redo widget")
            .setItems(names.toArray(new String[0]),(di,n)->bindWidget(choices.get(n))).show();
    }
    private void bindWidget(AppWidgetProviderInfo info) {
        int widgetId=widgetHost.allocateAppWidgetId();pendingWidget=widgetId;
        if(widgetManager.bindAppWidgetIdIfAllowed(widgetId,info.provider)) finishWidgetBind(widgetId);
        else {
            Intent request=new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);
            request.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,widgetId);
            request.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER,info.provider);
            try {startActivityForResult(request,WIDGET_BIND);}
            catch(Exception ex) {widgetHost.deleteAppWidgetId(widgetId);pendingWidget=-1;tip("Widget binding unavailable.");}
        }
    }
    private void finishWidgetBind(int widgetId) {
        AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(widgetId);
        if(info==null){clearPendingWidget();return;}
        if(info.configure!=null){
            Intent configure=new Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE);
            configure.setComponent(info.configure);configure.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,widgetId);
            try {startActivityForResult(configure,WIDGET_CONFIG);return;}
            catch(Exception ex){clearPendingWidget();tip("Widget configuration wasn't available.");return;}
        }
        saveWidget(widgetId);
    }
    private void saveWidget(int id){
        int old=store.getNumber("kotatsu_widget",-1);
        if(old!=-1 && old!=id) try{widgetHost.deleteAppWidgetId(old);}catch(Exception ignored){}
        store.putNumber("kotatsu_widget",id);pendingWidget=-1;
        showPage("recents");tip("Kotatsu-Redo widget connected.");
    }
    private void clearPendingWidget() {
        if(pendingWidget!=-1)try{widgetHost.deleteAppWidgetId(pendingWidget);}catch(Exception ignored){}
        pendingWidget=-1;
    }
    private void disconnectWidget(){
        int id=store.getNumber("kotatsu_widget",-1);
        if(id!=-1)try{widgetHost.deleteAppWidgetId(id);}catch(Exception ignored){}
        store.putNumber("kotatsu_widget",-1);store.putFlag("kotatsu_home",false);showPage("settings");
    }
    private void addKotatsuWidgetIfConnected(){
        int id=store.getNumber("kotatsu_widget",-1);
        if(id<0)return;
        AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(id);
        if(info==null){store.putNumber("kotatsu_widget",-1);return;}
        TextView h=text("Kotatsu-Redo · Recent manga",17,true);
        body.addView(h,lp(-1,40));
        try {
            AppWidgetHostView view=widgetHost.createView(this,id,info);
            view.setBackground(bg(Color.rgb(250,250,250),BLACK,12,1));
            body.addView(view,lp(-1,195));
            gap(body,13);
        } catch(Exception e) {
            TextView fail=outlined("Widget unavailable  ·  reconnect in Settings",12,false);
            body.addView(fail,lp(-1,54));fail.setOnClickListener(v->showPage("settings"));
            gap(body,12);
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==COVER_REQUEST){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && coverBookId!=null) {
                Uri uri=data.getData();
                try {getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                BookStore.Book b=store.byId(coverBookId);
                if(b!=null){b.coverUri=uri.toString();store.save(b);showPage("home");}
            }
            coverBookId=null;
            return;
        }
        if(requestCode==WIDGET_BIND){
            if(resultCode==RESULT_OK){int id=data==null?pendingWidget:data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,pendingWidget);finishWidgetBind(id);}
            else clearPendingWidget();
        } else if(requestCode==WIDGET_CONFIG){
            if(resultCode==RESULT_OK)saveWidget(pendingWidget); else clearPendingWidget();
        }
    }
}
