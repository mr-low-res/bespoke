# Build Bespoke APK without Android Studio

This project includes a GitHub Actions workflow that **can build** a standard debug APK using GitHub's Android build environment. It is not a prebuilt APK; it has not been compiled or tested in this chat.

## Steps

1. Create a free GitHub repository (for example `Bespoke`) and upload **all contents of this folder**, including the hidden `.github/workflows/build-apk.yml` file. The repository can be private.
2. Go to the repository's **Actions** tab, select **Build Bespoke APK**, then click **Run workflow**. The workflow also runs when you push to `main` or `master`.
3. When the workflow succeeds, open the run's summary and download **Bespoke-debug-APK** under **Artifacts**.
4. Unzip that downloaded artifact. The file inside is `app-debug.apk`. Copy it to your BOOX Poke 2 and open it to install.
5. Open Bespoke from the device's app list. Test before choosing it as your default launcher.

## Caveats

- The workflow builds **without the optional BOOX SDK library**. Standard launcher screens and native Android widget-hosting code are included, but E Ink refresh mode and low-light features need real Poke 2 testing, and may fall back to system controls.
- A successful build does not guarantee that the launcher behaves as intended on BOOX Poke 2 hardware.
- If the Actions workflow reports a build error, share its log so it can be fixed. Compilation has not been verified here.
- If you create additional APKs later, debug signing keys may differ from earlier builds on different machines; if Android rejects an update due to signatures, back up the app's local data before uninstalling.
