# Bespoke 0.1 — BOOX Poke 2 launcher

**Android Studio source project. Not a prebuilt APK.**

Bespoke is a minimalist, reading-first Android 9 home screen for the BOOX Poke 2, based on the approved monochrome mockups. It is *not* a replacement operating system. It does not require root access.

## Features included

- Portrait home screen with **one oversized featured cover** and title, reader, progress, chapter and a small Recents button.
- **Normal / Manga / Fast** selector (Manga is the user-facing label for Regal) and the separate square front-light button.
- Recents and Library screens with grayscale cover cards, manually managed title/progress, and tap-to-open reading app.
- Grayscale app drawer, grouped into reading, manga/comics, and other applications.
- Bottom shortcuts: Library, Apps, Refresh, Settings.
- Android HOME intent filter (can be selected as default home app).
- Android app-widget host to display **Kotatsu-Redo's native recent-manga widget** on the Recents screen, with standard user permission and widget setup screens.
- Persisted local bookshelf; uses Android's file picker for user-selected book/manga covers.
- Experimental BOOX SDK reflection support and a safe fallback when hardware access fails.

## What is not automatic yet

- The big featured cover is chosen via **Bespoke's Library**. It does not automatically track the last-opened title in Kotatsu-Redo, Kindle, KOReader, or NeoReader. Android prevents cross-app private database access.
- Connecting Kotatsu-Redo's **native widget** can automatically show its recent manga **inside Recents**, or optionally in the large featured Home area (enable in Settings). Native widget styling depends on Kotatsu-Redo, not on Bespoke.
- Tapping a manual book card opens the selected **reading app**, not a guaranteed exact book or chapter.
- Normal/Manga/Fast are tried against the Onyx EPD SDK **for Bespoke's own window**. System-wide settings / other apps are controlled by BOOX firmware. A mode button always reports if it couldn't apply a display change. Regal on older SDK firmware may be missing.
- Light button attempts off ↔ 3/255 white-channel brightness (~1% raw level) **only if** the Poke 2's known white backlight sysfs node is already writable by the app. On most stock firmware this is *not* permitted; in that case Bespoke offers system Display settings. Warm channel isn't touched. This is experimental and should be tested on device.

## Build in Android Studio

1. Install **Android Studio** (JDK 17+, Android SDK Platform 34 and Build Tools).
2. Open the folder `Bespoke/` as a project.
3. Gradle plugin: 8.5.2; Gradle distribution: 8.7. The included `./gradlew` script downloads the official Gradle 8.7 distribution over HTTPS and checks its SHA-256 before running. It is a minimal bootstrap, not the standard Gradle wrapper JAR. In Android Studio, choose Gradle 8.7 or configure a local installation if wrapper sync is not automatically recognized.
4. **Onyx SDK is enabled by default** via `onyxSdkEnabled=true` in `gradle.properties`. It's fetched from BOOX's official Maven repository. If it is unavailable, set `onyxSdkEnabled=false`; general launcher functions will still build, but direct BOOX API calls may be unavailable.
5. Sync the project and choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Install `app/build/outputs/apk/debug/app-debug.apk` on the BOOX Poke 2 via USB/ADB or transfer the APK to the reader and open it.
7. Open Bespoke from Apps first. Test it before setting it as your default home app. Then use **Bespoke Settings → Choose default launcher**.

### Connect Kotatsu-Redo

Install Kotatsu-Redo and open it at least once. Then go to **Bespoke Settings → Connect recent-manga widget**, choose Kotatsu-Redo's **Recent** widget, approve Android's binding prompt, and complete Kotatsu's widget configuration if shown. Visit **Recents** to see the widget. Under **Settings**, optionally turn on **Home cover: Kotatsu widget** to use the live widget instead of the manual feature image. If your fork build doesn't expose the widget, Bespoke will say so.

### Add your big cover

**Settings → Add book or manga**. Enter the title, progress and reading app. After Save, select a cover image from the device. Long-press a book card to change the cover or progress. The last-added or last-opened Bespoke book appears large on Home.

## Recovery / uninstall

This is an ordinary launcher APK and cannot replace your original BOOX firmware. Switch back to the stock BOOX launcher using Android's Home settings (or clear Bespoke's default home-app setting) if needed. Keep the original launcher installed.

## Privacy / safety

Bespoke keeps metadata and cover URI permissions in on-device SharedPreferences. No network permission, analytics, uploads or account access are requested. Images remain user-selected and the Kotatsu-Redo widget is hosted via Android's standard AppWidgetHost interface.

## Development verification

This project was authored and source-checked in an environment without the Android SDK/build-tools and without network access to Gradle or the BOOX SDK. Therefore **no APK was compiled or device-tested here**. The project should be opened and compiled in Android Studio, and hardware-specific functionality tested on a real Poke 2.

## Relevant upstream documentation

- [BOOX official OnyxAndroidDemo](https://github.com/onyx-intl/OnyxAndroidDemo)
- [Kotatsu-Redo](https://github.com/Kotatsu-Redo/Kotatsu-Redo)
- [Android widget host API](https://developer.android.com/develop/ui/views/appwidgets/host)

## Reference UI images

`docs/approved-home-mockup.png`, `docs/recents-concept.png`, and `docs/apps-concept.png` are **design mockups**, not captures from a compiled device. The app approximates these layouts with native Android views and real installed-app icons.


## Cloud build (no Android Studio required)

A GitHub Actions build workflow is included in `.github/workflows/build-apk.yml`. See `CLOUD-BUILD.md` for instructions. This workflow has not yet been run and may need fixes after the first compile attempt.
